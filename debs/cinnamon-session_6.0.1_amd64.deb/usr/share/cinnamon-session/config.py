# Generated file - DO NOT EDIT.  Edit config.py.in instead.

LOCALE_DIR="/usr/share/locale"
PACKAGE="cinnamon-session"
VERSION="6.0.1"
DBUS_ADDRESS="unix:abstract=cinnamon-session-quit-dialog"
PKG_DATADIR="/usr/share/cinnamon-session"
